# Find falsely labeled data points in group-B data
	* for females falsely labeled as males
	* and for males falsely labeled as females.
In the data set found [here](https://docs.google.com/spreadsheets/d/12rXTZLVkt89cfgsUVVd4dz1yj9Tci2Idr5RExWox47U/edit?usp=sharing)

## Use the equation of a line in the 2D plane: Y=M(X)+B

For an arbitrary point not lying on our negatively sloping line, plug its X value into the equation for the line to produce a corresponding Y value (Let's call that YL.) 

	Let's call the Y value of our arbitrary point YP. 

Take the difference between the two:  YL−YP=ΔY

    • If ΔY is positive, the point lies below and to the left of the line.
    • If ΔY is negative the point lies above and to the right of the line.


---

When groupB data was charted, we placed a line on the chart that was defined by the equation Y = -36.97(X) + 361.56.

The point (5.842298801 , 145.1950125) was pre-labled as "Male" by a human

1. Plugging that point into the equation of our line, we get Y = -36.97(5.842298801) + 361.56
2. The YL value (Y value on the line) for this X value is found to be 157.5702133
3. The YP value (Y value for this point) is 145.1950125
4. Plug value into the Formula YL-YP = ΔY &rarr; 157.5702133 - 145.1950125 = 12.3752008
5. ΔY is positive, the point lies below and to the left of the line (Which is supposed to be all Female)

The point (5.842298801 , 145.1950125) is falsely labeled female by the algorithm.
