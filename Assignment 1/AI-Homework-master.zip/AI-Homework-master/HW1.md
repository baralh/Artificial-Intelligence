# CMSC 409 Artificial Intelligence Project #1
---
## Part 1. (A)
[Finding false positives](https://github.com/coffee247/AI-Homework/blob/master/Finding-False-Positives.md) (a readme on this github)  Solution implemented in [Chart & GroupB data](https://docs.google.com/spreadsheets/d/12rXTZLVkt89cfgsUVVd4dz1yj9Tci2Idr5RExWox47U/edit?usp=sharing)


[Chart & GroupA data](https://docs.google.com/spreadsheets/d/1H4vYwX2RW_QOJhGsVrHvz2EhvB7noc0ATZGyfLVK6g4/edit?usp=sharing)

[Chart & GroupB data](https://docs.google.com/spreadsheets/d/12rXTZLVkt89cfgsUVVd4dz1yj9Tci2Idr5RExWox47U/edit?usp=sharing)

[Chart & GroupC data](https://docs.google.com/spreadsheets/d/1b3XJKVprhFrlmQp7wsi1N6A9slF-Ua_Tva4G6fUzubQ/edit?usp=sharing)

[SVG's of three charts](https://drive.google.com/open?id=1tdBD_IMovDpZpCFGPj-E4ykzcU8_2ouE)

---
## Part 1. (B)

[Truth Table](https://docs.google.com/spreadsheets/d/1B2jQG-PJI7oNSIaavOBaXb9AJ2nXQXSPwzPSetYhzSw/edit?usp=sharing)
