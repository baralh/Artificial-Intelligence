## Jim
Data-sets A, B, and C, are three hypothetical data-sets intended for use as training data when building an AI  model that classifies new data as male or female.


When plotted in a two-dimensional Cartesian plane, the three data-sets exhibit largely different clustering behaviors relative to the known sexes of the data-set values.  

## Jedidiah
With data set A’s Male and Female clusters, the two clusters are farther apart than in data set B or in data set C. This allows Males and Females to be easily separated using either weight or height as only one characteristic is needed to discern Males from Females, and vice versa. 


In data set B, the Male and the Female clusters are much closer together than in data set A, causing a slight overlap between the two clusters. This makes it a little more difficult to separate Males from Females, and vice versa. 


For data set C, the Male and the Female clusters are on top of each other, making it very difficult to properly differentiate Males from Females, and vice versa.


The definition of data set A’s neuron had the better accuracy (100%) of all the data sets as there was no overlap of Males and Females. Data set B’s neuron gave an accuracy close to that of data set A (98.76%) since there was very little overlap between the Male and Female clusters. Data set C’s neuron definition showed the worst accuracy (52.23%) due to both clusters nearly occupying the same space.


From the neuron model of data set A to data set B to data set C, the weights for the height increment into the positives and the weights for the bias decrement into the negatives. This shows that each data set requires a greater emphasis on the importance of the inputs. Primarily, the height and the bias are seen to have a greater presence than weight. In data set A, weight is not even a factor.

## Heman

In the first scenario data set of male and female are fartherapart which help us to study it more easily. Females height were lower than 5.5and their weight was below 145 whereas every male height was greater than 5.5and their height was significantly higher than the female. For the second data set,male and female sets of data overlap in a minimal matter. Females data werestill on the bottom left side of the plane compared to male data, but some datado create some overlap which generated false positive and false negative value inour analysis. In the third data set, both male and female data were clustered togetherin the same place due to the similarities in their height and weight. Both male data bodies were interlocked together so we had to pick a right spot for usto separate the two data set in order to calculate their confusion matrix. Due tothis reasoning, this data created lots of false-positive and false-negative in ourdata. 
